// main.tsx
import React from "react";
import ReactDOM from "react-dom/client";

import "./index.css";       // aquí importa tu CSS Tailwind
import Login from "./Login";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <Login></Login>
  </React.StrictMode>
);
